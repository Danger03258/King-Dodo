King Dodo Android App - Generated project

How to build APK (requires Android Studio & SDK):

1. Open Android Studio -> Open an Existing Project -> select the folder /mnt/data/KingDodo_Android_Project/app
2. Let Gradle sync. You may need to install Android Gradle Plugin 7.4.2 and compileSdk 33.
3. Connect an Android device or use the emulator, then Build -> Build Bundle(s) / APK(s) -> Build APK(s).
4. Install the generated APK on your device.

Notes:
- The app requests RECORD_AUDIO permission at runtime.
- WebView loads the bundled index.html from assets/www/index.html.
- If you want me to generate a debug-signed APK here, I cannot build inside this environment, but I can:
  * provide a signed/un-signed build script or
  * guide you step-by-step to build locally or via GitHub Actions.

App name: King Dodo
Package: com.kingdodo.app
